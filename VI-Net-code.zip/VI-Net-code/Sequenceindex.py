from __future__ import print_function, division
import os
import torch
import pandas as pd

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils
import torchvision.transforms.functional as F
import PIL
from PIL import Image
import csv
from scipy import misc

class Sequenceindex(Dataset):
    
    def __init__(self, csv_file, root_dir,stage,block_size=12):
        
        self.sequencelist= pd.read_csv(os.path.join(root_dir,stage,csv_file))
        self.root_dir = root_dir
        self.block_size=block_size

    def __len__(self):
        return len(self.sequencelist)

    def __getitem__(self, idx):
        
        action_type = self.sequencelist.iloc[idx, 1]
        score=self.sequencelist.iloc[idx, 5]
        class_number=0
        if action_type=='Normal':
            class_number=1
        else:
            class_number=0
            
        index ={'idx':idx,'class':class_number,'score':score}    
        return index
    
    
    
    
    
    
    
    
    