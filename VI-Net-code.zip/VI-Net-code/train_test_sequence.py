from __future__ import print_function, division

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
import numpy as np
import torchvision
from torchvision import datasets, models, transforms
import matplotlib.pyplot as plt
import time
import os
import copy
import math
import scipy.stats as ss
import sys
from progressbar import ProgressBar

def train_test_sequence(model, class_numbers,dataloader_train,dataloader_test,sequence_test,dataset_train_size,dataset_test_size,criterion,optimizer, scheduler,model_name,num_epochs=25):
    
    since = time.time()
    best_model=model
    best_loss=math.inf
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    best_cor=-1.0
    
    for epoch in range(num_epochs):
        #model = best_model
        print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        print('-' * 10)
        train_bar=ProgressBar()
        test_bar=ProgressBar()
        model.train()  # Set model to training mode
        scheduler.step()
        running_loss = 0.0
        epoch_train_loss=0.0
        running_corrects=0.0
        loss=0.0
        correlation_results=[]
        for data in train_bar(dataloader_train):
            
            inputs=data['sequence']
            labels=data['score']
            labels=torch.reshape(labels,[inputs.size(0),1])

            inputs = inputs.to(device)
            labels = labels.to(device)
            labels = torch.reshape(labels,[labels.size(1),labels.size(0)])
            labels = labels[0]

            inputs= inputs.to(device)
            labels= labels.to(device)

            optimizer.zero_grad()
            with torch.set_grad_enabled(True):
                outputs = model(inputs.float())
                try:
                    _,preds=torch.max(outputs, 1)
                except:
                    outputs = outputs.view(1, outputs.size(0))
                    _, preds = torch.max(outputs, 0)

                outputs=outputs.to(device)

                
                loss = criterion(outputs, labels.long())
                loss.backward()

                optimizer.step()
                try:
                    for i in range(labels.size(0)):
                        if preds[i]==labels[i].long():
                            running_corrects +=1
                except:
                    if preds == labels[i].long():
                        running_corrects += 1
                ######################
                #print(labels)
                #ou=torch.reshape(outputs,[1,outputs.size(0)])
                
                #print(ou)
                ######################
                a=labels.long().cpu().detach().numpy()
                b=preds.cpu().detach().numpy()
                correlation_results2=[]
                for i in range(inputs.size(0)):
                    
                    correlation_results.append([])
                    correlation_results[0].append(a[i])

                    correlation_results.append([])
                    try:
                        correlation_results[1].append(b[i])
                    except:
                        correlation_results[1].append(b)

                    correlation_results2.append([])
                    correlation_results2[0].append(a[i])

                    correlation_results2.append([])
                    try:
                        correlation_results2[1].append(b[i])
                    except:
                        correlation_results2[1].append(b)
                    
                #print(correlation_results2[0])
                #print(correlation_results2[1])
                #print(ss.spearmanr(correlation_results2[0],correlation_results2[1]))

            running_loss += loss.item()*inputs.size(0)
            torch.save(best_model,'test.pt')
        epoch_train_loss = running_loss / dataset_train_size
        epoch_train_acc = running_corrects / dataset_train_size
        print('{} Loss: {:.4f} acc{:.4f}'.format('train', epoch_train_loss, epoch_train_acc))
        print(ss.spearmanr(correlation_results[0],correlation_results[1]))
        #torch.save(model,middel_model_name)
        
        #corr_result=train_test_SVM_sequence( middel_model_name,dataloader_train2,dataloader_test,sequence_train,sequence_test,dataset_train2_size,dataset_test_size,feature_lenght,feature_size=2048)
        #if math.isnan(corr_result) == False: 
            #if  corr_result > best_cor:
                #best_cor = corr_result
                #best_model = model
                #torch.save(best_model,model_name)
        
        model.eval()
        running_loss = 0.0
        epoch_test_loss=0.0
        loss=0.0
        correlation_results=[]
        with torch.no_grad():
            for data in test_bar(dataloader_test):
                idx=data['idx'].numpy()
                labels=data['score']
                labels= labels.to(device)
                idx2=idx[0]
                data2=sequence_test[idx2]
                sequence=data2['sequence']
                sequence=sequence.to(device)
                
               
                mean_outputs=torch.zeros([1,class_numbers])
                mean_outputs=mean_outputs.to(device)
                for i in range(sequence.size(0)):
                    inputs=sequence[i,:,:,:,:]
                    inputs=torch.reshape(inputs,[1,sequence.size(1),sequence.size(2),sequence.size(3),sequence.size(4)])
                    inputs=inputs.to(device)
                    
                    
                    outputs=model(inputs.float())
                    outputs=outputs.to(device)
                    #print(outputs.size())
                    mean_outputs+=outputs
                    
                mean_outputs=mean_outputs/sequence.size(0)
                _,preds=torch.max(mean_outputs,1)
                loss= criterion(mean_outputs, labels.long())
                running_loss += loss.item()
                a =labels.long().cpu().detach().numpy()
                b =preds.cpu().detach().numpy()
                
                for i in range(inputs.size(0)):
                     
                    correlation_results.append([])
                    correlation_results[0].append(a[0])
                    
                    correlation_results.append([])
                    correlation_results[1].append(b[0])
                #print(correlation_results[0])
                #print(correlation_results[1])
        
            #normal_acc=normal_n/normal_t
            #abnormal_acc=abnormal_n/abnormal_t
        epoch_test_loss = running_loss / dataset_test_size
        print('----------mean results-----------')
        sys.stdout.write("\033[0;32m")
        print('{} Loss: {:.4f} '.format('test', epoch_test_loss))
        sys.stdout.write("\033[0;0m")
        print(ss.spearmanr(correlation_results[0],correlation_results[1]))
        print(correlation_results[0])
        print(correlation_results[1])
        
        if math.isnan(ss.spearmanr(correlation_results[0],correlation_results[1])[0])== False: 
            if  ss.spearmanr(correlation_results[0],correlation_results[1])[0] > best_cor:
                best_cor = ss.spearmanr(correlation_results[0],correlation_results[1])[0]
                best_model=model
                torch.save(best_model,model_name)
                #print(correlation_results[0])
                #print(correlation_results[1])
                sys.stdout.write("\033[1;34m")
                print('model was saved')
                sys.stdout.write("\033[0;0m")
        print()   
           
    time_elapsed = time.time() - since
    print('Training complete in {:.0f}m {:.0f}s'.format(
        time_elapsed // 60, time_elapsed % 60))
    print('Best loss: {:4f}'.format(best_loss))
    return best_model