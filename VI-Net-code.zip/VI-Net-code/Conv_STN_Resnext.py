from __future__ import print_function, division
import os
import torch
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils, models,transforms, utils
import torchvision.transforms.functional as F
import PIL
from PIL import Image
import csv
from scipy import misc
import matplotlib.pyplot as plt
import networkx as nx
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import datasets, models,transforms, utils


class Conv_STN_Resnext(nn.Module):
    def __init__(self, class_numbers, heatmaps_number=15, size_of_video_clips=16):
        super(Conv_STN_Resnext, self).__init__()
        
        self.class_numbers = class_numbers
        self.heatmaps_number = heatmaps_number
        self.size_of_video_clips = size_of_video_clips
        
        # first CNN layer to combine joint heatmaps on 16 frames
        self.conv1 = nn.Conv2d(self.size_of_video_clips, 1, kernel_size=(3,3), stride=(1,1),padding=1,groups=1, bias=False)
        self.bn1 = nn.BatchNorm2d(1)
        
        resnet = models.resnext50_32x4d(pretrained=True)
        #resnet=torch.hub.load('pytorch/vision:v0.5.0', 'resnext101_32x8d', pretrained=True)
        resnet.conv1 = nn.Conv2d(self.heatmaps_number, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
        num_ftrs = resnet.fc.in_features
        resnet.fc = nn.Linear(num_ftrs, self.class_numbers, bias=True)
        
        self.resnet = resnet
        self.relu = nn.ReLU()
        
        
        # Spatial transformer localization-network
        self.localization = nn.Sequential(
            nn.Conv2d(1, 10, kernel_size=7),
            nn.MaxPool2d(2, stride=2),
            nn.ReLU(True),
            nn.Conv2d(10, 10, kernel_size=5),
            nn.MaxPool2d(2, stride=2),
            nn.ReLU(True)
        )

        # Regressor for the 3 * 2 affine matrix
        self.fc_loc = nn.Sequential(
            nn.Linear(10 * 52 * 52, 32),
            nn.ReLU(True),
            nn.Linear(32, 3 * 2)
        )

        # Initialize the weights/bias with identity transformation
        self.fc_loc[2].weight.data.zero_()
        self.fc_loc[2].bias.data.copy_(torch.tensor([1, 0, 0, 0, 1, 0], dtype=torch.float))
    # Spatial transformer network forward function
    def stn(self, x):
        xs = self.localization(x)
        xs = xs.view(-1, 10 * 52 * 52)
        theta = self.fc_loc(xs)
        theta = theta.view(-1, 2, 3)
        theta[:,:,2]=0
        grid = F.affine_grid(theta, x.size())
        x = F.grid_sample(x, grid)

        return x
    def forward(self, x):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        firstconv=torch.zeros([x.size(0),self.heatmaps_number,x.size(3),x.size(4)])
        firstconv=firstconv.to(device)
        size=self.size_of_video_clips
        for i in range(self.heatmaps_number):
            firstconv[:,i,:,:] = self.stn(self.relu(self.bn1(self.conv1(x[:,0,i*size:(i+1)*size,:,:]))))[:,0,:,:]
        out = (self.resnet(firstconv))
        return  out



class Conv_STN_Resnext_2(nn.Module):
    def __init__(self, class_numbers, heatmaps_number=15, size_of_video_clips=16):
        super(Conv_STN_Resnext_2, self).__init__()

        self.class_numbers = class_numbers
        self.heatmaps_number = heatmaps_number
        self.size_of_video_clips = size_of_video_clips

        resnet = models.resnext50_32x4d(pretrained=True)
        resnet.conv1 = nn.Conv2d(self.heatmaps_number*self.size_of_video_clips, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3),
                                 bias=False)
        num_ftrs = resnet.fc.in_features
        resnet.fc = nn.Linear(num_ftrs, self.class_numbers, bias=True)

        self.resnet = resnet
        self.relu = nn.ReLU()

    def forward(self, x):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        h = torch.zeros([x.size(0), self.heatmaps_number * self.size_of_video_clips, x.size(3), x.size(4)])
        h = x[:, 0, :, :, :]
        out = self.resnet(h)
        return out

