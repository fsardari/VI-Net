from __future__ import print_function, division
import os
import torch
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils
import torchvision.transforms.functional as F
import PIL
from PIL import Image
import csv
from scipy import misc


class Clip(Dataset):

    def __init__(self, csv_file, annotation_dir, img_dir, stage, block_size, heatmaps_numbers, image_size=None):

        self.pose = pd.read_csv(os.path.join(annotation_dir, stage, csv_file))
        self.annotation_dir = annotation_dir
        self.img_dir = img_dir
        self.img_size = image_size
        self.block_size = block_size
        self.stage = stage
        self.heatmap_numbers = heatmaps_numbers

    def __len__(self):
        return len(self.pose) // self.block_size

    def __getitem__(self, idx):
        final_image = np.zeros((1, self.heatmap_numbers * self.block_size, self.img_size, self.img_size))

        action_name = self.pose.iloc[idx * self.block_size, 0]
        action_type = self.pose.iloc[idx * self.block_size, 1]
        abnormality_type = self.pose.iloc[idx * self.block_size, 2]
        subject_name = self.pose.iloc[idx * self.block_size, 3]
        first_folder_name = self.pose.iloc[idx * self.block_size, 4]
        last_folder_name = self.pose.iloc[(idx + 1) * self.block_size - 1, 4]
        image_type = self.pose.iloc[idx * self.block_size, 5]
        first_device_number = self.pose.iloc[idx * self.block_size, 6]
        last_device_number = self.pose.iloc[(idx + 1) * self.block_size - 1, 6]
        score = self.pose.iloc[idx * self.block_size, 8].astype('int')

        subfolder = 'COLOR'

        if action_type == 'Normal':
            image_direction = action_name + '/' + self.stage + '/' + action_type + '/' + subject_name + '/' + str(
                first_folder_name) + '/' + first_device_number + '/' + subfolder + '/'

        else:
            image_direction = action_name + '/' + self.stage + '/' + action_type + '/' + abnormality_type + '/' + subject_name + '/' + str(
                first_folder_name) + '/' + first_device_number + '/' + subfolder + '/'

        if first_folder_name == last_folder_name and first_device_number == last_device_number:
            for m in range(self.block_size):
                j = m + idx * self.block_size
                img_name = self.pose.iloc[j, 7]
                image = Image.open(os.path.join(self.img_dir, image_direction, img_name)).convert('L')
                [w, h] = image.size
                heatmaps_numbers2 = 78
                width = w / heatmaps_numbers2
                ymin = 0
                ymax = h
                xmin = 0
                xmax = width

                for i in range(self.heatmap_numbers):
                    xmin = (i) * width
                    xmax = xmin + width
                    img = image.crop((xmin, ymin, xmax, ymax))
                    img = img.resize((self.img_size, self.img_size), Image.ANTIALIAS)
                    final_image[:, i * self.block_size + m, :, :] = np.array(img)

        else:
            final_image = np.zeros((1, self.heatmap_numbers * self.block_size, self.img_size, self.img_size))
            for m in range(self.block_size):
                j = idx * self.block_size - self.block_size + 1 + m
                img_name = self.pose.iloc[j, 7]
                image = Image.open(os.path.join(self.img_dir, image_direction, img_name)).convert('L')
                [w, h] = image.size
                heatmaps_numbers2 = 78
                width = w / heatmaps_numbers2
                ymin = 0
                ymax = h
                xmin = 0
                xmax = width

                for i in range(self.heatmap_numbers):
                    xmin = (i) * width
                    xmax = xmin + width
                    img = image.crop((xmin, ymin, xmax, ymax))
                    img = img.resize((self.img_size, self.img_size), Image.ANTIALIAS)
                    final_image[:, i * self.block_size + m, :, :] = np.array(img)

        if action_type == 'Normal':
            action_type2 = 1
        else:
            action_type2 = 0
        sample = {'sequence': final_image, 'foldername': first_folder_name, 'devicenumber': first_device_number,
                  'actiontype': action_type2, 'score': score}
        return sample

# class Clip(Dataset):
#
#     def __init__(self, csv_file, annotation_dir, img_dir, stage, block_size, heatmaps_numbers, image_size=None):
#
#         self.pose = pd.read_csv(os.path.join(annotation_dir, stage, csv_file))
#         self.annotation_dir = annotation_dir
#         self.img_dir = img_dir
#         self.img_size = image_size
#         self.block_size = block_size
#         self.stage = stage
#         self.heatmap_numbers = heatmaps_numbers
#
#     def __len__(self):
#         return len(self.pose) // self.block_size
#
#     def __getitem__(self, idx):
#         final_image = np.zeros((1, self.heatmap_numbers * self.block_size, self.img_size, self.img_size))
#
#         action_name = ''
#         action_type = ''
#         folder_name = ''
#         device_number = ''
#         abnormality_type = ''
#         first_folder_name = ''
#         last_folder_name = ''
#
#         for m in range(self.block_size):
#             j = m + idx * self.block_size
#             action_name = self.pose.iloc[j, 0]
#             action_type = self.pose.iloc[j, 1]
#             abnormality_type = self.pose.iloc[j, 2]
#             subject_name = self.pose.iloc[j, 3]
#             folder_name = self.pose.iloc[j, 4]
#             if m == 0:
#                 first_folder_name = folder_name
#             elif m == 15:
#                 last_folder_name = folder_name
#
#             image_type = self.pose.iloc[j, 5]
#             device_number = self.pose.iloc[j, 6]
#             img_name = self.pose.iloc[j, 7]
#             score = self.pose.iloc[j, 8].astype('int')
#             subfolder = 'COLOR'
#
#             if action_type == 'Normal':
#                 image_direction = action_name + '/' + self.stage + '/' + action_type + '/' + subject_name + '/' + str(
#                     folder_name) + '/' + device_number + '/' + subfolder + '/' + img_name
#
#             else:
#                 image_direction = action_name + '/' + self.stage + '/' + action_type + '/' + abnormality_type + '/' + subject_name + '/' + str(
#                     folder_name) + '/' + device_number + '/' + subfolder + '/' + img_name
#
#             image = Image.open(os.path.join(self.img_dir, image_direction)).convert('L')
#             [w, h] = image.size
#             heatmaps_numbers2 = 78
#             width = w / heatmaps_numbers2
#             ymin = 0
#             ymax = h
#             xmin = 0
#             xmax = width
#
#             for i in range(self.heatmap_numbers):
#                 xmin = (i) * width
#                 xmax = xmin + width
#                 img = image.crop((xmin, ymin, xmax, ymax))
#                 img = img.resize((self.img_size, self.img_size), Image.ANTIALIAS)
#                 final_image[:, i * self.block_size + m, :, :] = np.array(img)
#
#         if first_folder_name != last_folder_name:
#             final_image = np.zeros((1, self.heatmap_numbers * self.block_size, self.img_size, self.img_size))
#             for m in range(self.block_size):
#                 j = idx * self.block_size - self.block_size + 1 + m
#                 action_name = self.pose.iloc[j, 0]
#                 action_type = self.pose.iloc[j, 1]
#                 abnormality_type = self.pose.iloc[j, 2]
#                 subject_name = self.pose.iloc[j, 3]
#                 folder_name = self.pose.iloc[j, 4]
#                 image_type = self.pose.iloc[j, 5]
#                 device_number = self.pose.iloc[j, 6]
#                 img_name = self.pose.iloc[j, 7]
#                 score = self.pose.iloc[j, 8].astype('int')
#                 if image_type == 'RGB':
#                     subfolder = 'COLOR'
#                 else:
#                     subfolder = 'DEPTH'
#
#                 if action_type == 'Normal':
#                     image_direction = action_name + '/' + self.stage + '/' + action_type + '/' + subject_name + '/' + str(
#                         folder_name) + '/' + device_number + '/' + subfolder + '/' + img_name
#                 else:
#                     image_direction = action_name + '/' + self.stage + '/' + action_type + '/' + abnormality_type + '/' + subject_name + '/' + str(
#                         folder_name) + '/' + device_number + '/' + subfolder + '/' + img_name
#
#                 image = Image.open(os.path.join(self.img_dir, image_direction)).convert('L')
#                 [w, h] = image.size
#                 heatmaps_numbers2 = 78
#                 width = w / heatmaps_numbers2
#                 ymin = 0
#                 ymax = h
#                 xmin = 0
#                 xmax = width
#
#                 for i in range(self.heatmap_numbers):
#                     xmin = (i) * width
#                     xmax = xmin + width
#                     img = img.resize((self.img_size, self.img_size), Image.ANTIALIAS)
#                     final_image[:, i * self.block_size + m, :, :] = np.array(img)
#
#         if action_type == 'Normal':
#             action_type2 = 1
#         else:
#             action_type2 = 0
#         sample = {'sequence': final_image, 'foldername': folder_name, 'devicenumber': device_number,
#                   'actiontype': action_type2, 'score': score}
#         return sample